# NDI® extension for Omniverse [mf.ov.ndi]
Copyright 2023 Moment Factory Studios Inc.

An extension to enable NDI® live video input in Omniverse.

- Requires Omniverse Kit >= 105
- Tested in USD Composer 2023.1.1
- Requires [NDI® 5.5.3 runtime for Windows](https://go.ndi.tv/tools-for-windows)
